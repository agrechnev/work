% Modified by Oleksiy Grechnyev
% No filtering at present

%% ========== Setting ========== %%
clear, close all;
clc;

%% ============== Pathes  ============== %%
addpath('IMU', 'Res', 'Map');

% 2017-05-26_10-12-38 IT-GYM
filename  = '2017-05-26_10-12-38_iOS_accelerometer.json';
ac_1      = strcat(pwd,'\Res\2017-05-26_10-12-38_iOS\', filename);
logger_1  = strcat(pwd,'\Res\2017-05-26_10-12-38_iOS\2017-05-26_10-12-38_iOS_angles.json');

set       = [0.2 0.5 0];   % Initial position
step_adj  = 2.2;

show      = imread ('IT_GYM_Office.png');
mask      = imread('mask_IT_GYM.png');
masktable = load('masktable_IT_GYM.out');
pixelSize = 0.007;

%  Log Information
%  1-9  sec - 10 steps
% 10-15 sec - 8 steps
% 20-23 sec - 4 steps
% 26-29 sec - 4 steps
% 34-37 sec - 4 steps
% 41-44 sec - 6 steps
% 48-53 sec - 7 steps
% 55-62 sec - 10 steps

%% ========== Settings ========== %%
settings.meshSteps = [0.3 0.3];
settings.samplePeriod = 0.033;
settings.t_show = 0;
settings.stationaryIndicator = 1.035;
settings.cutoffLow = 2.2;
settings.MapOrientationAngle = 20;

settings.filterFlag         = 'off';
settings.mapCorrectionFlag  = 'on';
settings.meshCorrectionFlag = 'on';
settings.maskCorrectionFlag = 'on';

if strcmpi(settings.maskCorrectionFlag, 'on')
    settings.mapCorrectionFlag = 'on';
end

%% ========== Initializations ========== %%
% Here we initialize all classes we will need in our program
pos_prev = set;
posprev = set;
% Plotter accumulates all functions for plotting the results
objPlotter = Plotter();
% Reader contains methods for data reading from JSON files and its
% transformation to a format used in program (JSON=> struct)
objReader = Reader('accelPath', ac_1, 'loggerPath', logger_1, 'isPrintable', 0);
% Step is a class who contains all methods used to detect the steps and
% remove the noise.
% I (Oleksiy Grechnyev) will not need step
% objStep = Step('samplePeriod', settings.samplePeriod , 'cutoffLow', settings.cutoffLow , 'stationaryIndicator', settings.stationaryIndicator);
% Convertor accumulates all the methods for convertion between euler angles
% and quaternions and inversely. Additionally, this method has the function
% to convert acceleration from local CS to global CS.
objConvertor = Convertor();

%% ========== Plotting Map ========== %%
objPlotter.fPlotRoomPixels(show, filename); % Plots the map of the office (coordinates in pixels)

%% ========== Read Logs ========== %%
objReader.fReadAccel(); % Reads acceleration from JSON
accel = objReader.accel; % Takes data from the property of the class.
objReader.fReadAngles(); % Reads angles from JSON
anglesLogger = objReader.anglesLogger; % Takes data from the property of the class.

% Apply filters: my style (Oleksiy Grechnyev)
if strcmpi(settings.filterFlag, 'on')
    display('Using Butterworth filter.');
    % This is how I would use filters
    % No idiotic pieces, the whole vector is processed in one go
    % Since filter (unlike filtfilt) is strictly casual
    % This can be done in real time by processing each input packet in turn
    % in the C++ code without any delays of 8 or 24 or anything like that
    
    % Filter coefficients
    [b, a] = butter(8, (2 * settings.cutoffLow)/(1/settings.samplePeriod), 'low' ); 
    
    % Apply the filter, would be much simpler if accel was not a vector of structs!
    % Maybe there's a simpler way, but I'm no goot at MatLab
    tempx = 1:length(accel);
    tempy = 1:length(accel);
    tempz = 1:length(accel);
    for t = 1:length(accel)
     tempx(t) = accel(t).x;
     tempy(t) = accel(t).y;
     tempz(t) = accel(t).z;
    end 
    tempx = filter(b, a, tempx);
    tempy = filter(b, a, tempy);
    tempz = filter(b, a, tempz);
    for t = 1:length(accel)
     accel(t).x = tempx(t);
     accel(t).y = tempy(t);
     accel(t).z = tempz(t);
    end 
    
else
    display('Using no filters.');
end


%% GENERAL CYCLE %%
vel = [0 0 0];  % Just to be sure
fileLog1 = fopen('readLog.dat', 'w');
fileLog2 = fopen('procLog.dat', 'w');
fprintf(fileLog1, '   t  :  tStamp  isS:    ax         ay         az           a      :    pitch       roll       yaw \n');
fprintf(fileLog2, '   t  :  tStamp  isS:    ax         ay         az           a      :    pitch       roll       yaw \n');

for t = 1:length(accel) 
    %% ========== Step Detection ========== %%
    % I (Oleksiy Grechnyev) removed the fancy filtering for now
    stationary = accel(t).x^2 + accel(t).y^2 + accel(t).z^2 < settings.stationaryIndicator^2;
    
    % Log the raw input data + stationary flag
    % Note for angles: [x y z] = [pitch roll yaw]
    
    % Log read data: passed successfully
    fprintf(fileLog1, '%5d : %10.6f %1d: ', t, accel(t).timestamp, stationary);
    acMod = sqrt(accel(t).x^2 + accel(t).y^2 + accel(t).z^2);
    fprintf(fileLog1, '%10.6f %10.6f %10.6f %10.6f : ', accel(t).x, accel(t).y, accel(t).z, acMod);
    fprintf(fileLog1, '%10.6f %10.6f %10.6f\n', anglesLogger(t).x, anglesLogger(t).y, anglesLogger(t).z);
    
    %% ========== AHRS Correction ========== %%
    % Here we initialize the property "angles of an object objConvertor with the angles detected by the device"
    anglesLogger(t).x = -anglesLogger(t).x;
    
    objConvertor.angles = [[anglesLogger(t).x];...
                           [anglesLogger(t).y];...
                           -[anglesLogger(t).z] - 180 + settings.MapOrientationAngle]';    
    
    %% ========== From local to Global ========== %%  
    objConvertor.quaternion = objConvertor.fGetQuaterionFromAngles(); % Convert from Euler angles to quaternion
    accGlobal = objConvertor.fFromLocalToGlobal([accel(t).x; accel(t).y; accel(t).z]'); % Converting acceleration from local CS to global CS
    % Transformation from RIGHT-HAND TO LEFT-HAND coordinate system
    accGlobal(2) = -accGlobal(2);
    
    % Logged global accel and processed angles
    fprintf(fileLog2, '%5d : %10.6f %1d: ', t, accel(t).timestamp, stationary);
    acMod = sqrt(accGlobal(1)^2 + accGlobal(2)^2 + accGlobal(3)^2);
    fprintf(fileLog2, '%10.6f %10.6f %10.6f %10.6f : ', accGlobal(1), accGlobal(2), accGlobal(3), acMod);
    fprintf(fileLog2, '%10.6f %10.6f %10.6f\n', objConvertor.angles(1), objConvertor.angles(2), objConvertor.angles(3));
    
    %% ========== ZUPT ========== %%
    %Zero-velocity detection is a vital part in inertial navigation system. 
    %Because inertial sensors are subject to drift, if periods of stationarity 
    %is not detected from time to time, errors in acceleration would be integrated 
    %in to velocity and position that lea1ds to drastic drift. Zero-velocity 
    %provides the required information to reset velocity.

    %ZUPT utilizes data from inertial sensor alone. It assumes that when the
    %sensor is stationary (reading is 0), velocity is zero and angular rate is 0
    %as well. One concern is that if the accelerometer is moving at a constant speed,
    %the algorithm would misjudge the motion as stationary.
    % But based on our practice, since the accelerometer is very sensitive
    %to accelerations, or, forces, and also because walking is a rather complex
    %course of acceleration and deceleration, the detection of zero velocity 
    %never failed because of misjudgment. 
    %There are times that motion detection threshold was not set properly which 
    %led to misjudging.
    if stationary == 1 
        % Velocity Reset
        vel = [0 0 0]; 
    else
        % V(i) = V(i-1) + a(i) * dt
    	vel(1,1) = vel(1,1) + 9.8 * accGlobal(1) * settings.samplePeriod;
        vel(1,2) = vel(1,2) + 9.8 * accGlobal(2) * settings.samplePeriod;
        vel(1,3) = vel(1,3) + 9.8 * accGlobal(3) * settings.samplePeriod;
    end
    
    %% ========== TRACKER ========== %%
    % S(i) = S(i-1) + V(i) * dt
    pos = pos_prev + step_adj * vel * settings.samplePeriod; 

    % Checking Is the point on the map? If not, then putting it on the map
    if strcmpi(settings.mapCorrectionFlag, 'on')
        coordInPixels = Checker.fCorrectIfIsNotOnMap(mask, ceil([pos(1), pos(2)]/pixelSize));
        % Converting from pixels to m
        pos(1) = coordInPixels(1) * pixelSize; 
        pos(2) = coordInPixels(2) * pixelSize;
    end

     % Was wall crossed?
    if strcmpi(settings.maskCorrectionFlag, 'on')
        if Checker.fCheck_obst(mask, ceil([pos_prev(1), pos_prev(2)] / pixelSize), ...
                                     ceil([pos(1), pos(2)] / pixelSize))
            % Trying to correct by vertical displacetemt Vx = 0;
            pos(1) = pos_prev(1);
            pos(2) = pos_prev(2) + step_adj * vel(2) * settings.samplePeriod;

            % Checking Is the point on the map? If not, then putting it on the map
            coordInPixels = Checker.fCorrectIfIsNotOnMap(mask, ceil([pos(1), pos(2)] / pixelSize));
            % Converting from pixels to m
            pos(1) = coordInPixels(1) * pixelSize;
            pos(2) = coordInPixels(2) * pixelSize;

            % Was wall crossed?
            if Checker.fCheck_obst(mask, ceil([pos_prev(1), pos_prev(2)] / pixelSize),...
                                         ceil([pos(1), pos(2)] / pixelSize))
                % Trying to correct by vertical displacetemt Vy = 0; 
                pos(1) = pos_prev(1) + step_adj * vel(1) * settings.samplePeriod;
                pos(2) = pos_prev(2);

                % Checking Is the point on the map? If not, then putting it on the map
                coordInPixels = Checker.fCorrectIfIsNotOnMap(mask, ceil([pos(1), pos(2)] / pixelSize));
                % Converting from pixels to m
                pos(1) = coordInPixels(1) * pixelSize;
                pos(2) = coordInPixels(2) * pixelSize;
                if Checker.fCheck_obst(mask, ceil([pos_prev(1), pos_prev(2)] / pixelSize),...
                                             ceil([pos(1), pos(2)] / pixelSize))
                    % if none of the corrections was successful then let it
                    % cross the wall
                    % integrate velocity to yield position
                    pos = pos_prev + step_adj .* vel * settings.samplePeriod;

                    % Checking Is the point on the map? If not, then putting it on the map
                    coordInPixels = Checker.fCorrectIfIsNotOnMap(mask, ceil([pos(1), pos(2)] / pixelSize));
                    % Converting from pixels to m
                    pos(1) = coordInPixels(1) * pixelSize;
                    pos(2) = coordInPixels(2) * pixelSize; 
                end
            end
        end
    end

    % If it is time to show the position, then
    if settings.t_show - accel(t).timestamp < 0
        % Link to the mesh using the fMeshCorrector function
        if strcmpi(settings.meshCorrectionFlag, 'on')
            coordInMeters = Checker.fMeshCorrector([pos(1), pos(2)], settings.meshSteps, ...
                                                   size(mask,1) * pixelSize, masktable);
            % Converting from pixels to m
            pos(1) = coordInMeters(1);
            pos(2) = coordInMeters(2);
        end
        % Plotter itself
        objPlotter.fPlotSimpleApproach([pos(1), pos(2)]/pixelSize, [posprev(1), posprev(2)]/pixelSize);
        % This is done to draw a line on the plot
        posprev = pos;
        settings.t_show = settings.t_show + 1;
    end
    
    % End of the current step. Current position becomes previous.
    pos_prev = pos;    
end
fclose(fileLog1);
fclose(fileLog2);
% ============================ THE END ================================== %



