classdef Plotter
%% Author:
%  Feliks Sirenko, sirenkofelix@gmail.com
%% Owner:
%  IT-Jim Company
%% Last update:
%  21/05/17
%% Class definition
%PLOTTER Class who contains all functions responsible for plotting the results
    methods (Access = public)
        %% Object Initializer
        function obj = Plotter()
        end
    end
    
    methods (Access = public)
        function fPlotRoomPixels(~, image, ass)
            %% fPLOTROOMPIXELS Plots office in pixels
            % INPUTS:
            % image - binary mask of the office
            figure('units','normalized','outerposition',[0 0 1 1])

            set(gca,'XTick',[]); 
            set(gca,'YTick',[]);
            imshow(image);
            title(ass);
            axis image
            hold on;
        end 
        function fPlotSimpleApproach (~, coord, coord_prev)
            plot([coord_prev(1,1); coord(1,1)], [coord_prev(1,2) coord(1,2)], 'LineStyle', '-', 'Marker', 'o', 'MarkerFaceColor', 'red', 'markersize',5,'DisplayName','Current coordinates');
            pause(0.01);
        end
    end
end



