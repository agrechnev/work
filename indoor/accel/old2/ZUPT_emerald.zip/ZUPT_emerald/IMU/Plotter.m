classdef Plotter
%% Author:
%  Feliks Sirenko, sirenkofelix@gmail.com
%% Owner:
%  IT-Jim Company
%% Last update:
%  21/05/17
%% Class definition
%PLOTTER Class who contains all functions responsible for plotting the results
%% Public properties
    properties (Access = public)
        fig;        
    end    

    methods (Access = public)
        %% Object Initializer
        function obj = Plotter()
        end
    end
    
    methods (Access = public)
        function fig = fPlotRoomPixels(~, image, ass)
            %% fPLOTROOMPIXELS Plots office in pixels
            % INPUTS:
            % image - binary mask of the office
            fig = figure('units','normalized','outerposition',[0 0 1 1]);

            set(gca,'XTick',[]); 
            set(gca,'YTick',[]);
            imshow(image);
            title(ass);
            axis image
            hold on;
        end 
        
        function fPlotSimpleApproach (obj, coord, coord_prev)
            figure(obj.fig);
            line([coord_prev(1) coord(1)], [coord_prev(2) coord(2)], ...
                'LineStyle', '-', 'Marker', 'o', 'MarkerFaceColor', 'red',...
                'MarkerSize', 5, 'DisplayName', 'Current coordinates');
            pause(0.01);
        end
    end
end



