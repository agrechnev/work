%% Function implements averaging sliding window filtering
% input   - data vector or matrix
% WS      - sliding window size
% modeStr - string described one of two modes:
%           "round" - data filtering using rounding input samples
%           "other str or empty" - ordinary filtering

function output = aswFiltering(input, WS, modeStr)

[X, Y] = size(input);
output = zeros(X, Y);

counter = WS;

if ~(X==1 || Y==1)    
    fifo_vector = zeros(WS, Y);
else
    N = length(input);
    fifo_vector = zeros(WS, 1);
end

if nargin==3
    if strcmp(modeStr, 'round')
        input = round(input);
    else
        warning(['Undefined function parameter - ' modeStr]);
        return
    end        
end

if ~(X==1 || Y==1)
    output(1:WS-1,:) = input(1:WS-1,:);
    fifo_vector(1:WS-1, :) = input(1:WS-1,:);
    for p=WS:X
        if counter <= WS
            fifo_vector(counter, :) = input(p,:);
            counter = counter + 1;
        else
            counter = 1;
            fifo_vector(counter, :) = input(p,:);
        end    
        output(p,:) = mean(fifo_vector,1);
    end
else
    output(1:WS-1) = input(1:WS-1);
    fifo_vector(1:WS-1) = input(1:WS-1);
    for p=WS:N
        if counter <= WS
            fifo_vector(counter) = input(p);
            counter = counter + 1;
        else
            counter = 1;
            fifo_vector(counter) = input(p);
        end    
        output(p) = mean(fifo_vector);
    end
end