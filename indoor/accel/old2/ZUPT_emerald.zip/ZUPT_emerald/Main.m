% Modified by Oleksiy Grechnyev
% No filtering at present

%% ========== Setting ========== %%
clear, close all;
clc;

%% ============== Pathes  ============== %%
addpath('IMU', 'Map');

pixelSize = 0.007;
show      = imread ('IT_GYM_Office.png');

%% ========== Settings ========== %%
% Initial position
set       = [0.3 1 0];   
%set       = [10.5 2.5 0];   

settings.meshSteps = [0.3 0.3];
settings.samplePeriod = 0.020;
settings.t_show = 1;
settings.t_step = 1;
settings.stationaryIndicator3 = 1.1;
settings.cutoffLow = 2.5;
settings.MapOrientationAngle = 20;
settings.filterOrder = 8;
settings.userAverageVelocity = 3.2;

settings.filterFlag         = 'off';
settings.mapCorrectionFlag  = 'off';
settings.meshCorrectionFlag = 'off';
settings.maskCorrectionFlag = 'off';

if strcmpi(settings.maskCorrectionFlag, 'on')
    settings.mapCorrectionFlag = 'on';
end
settings.debugFlag          = 'on';
settings.saveJSON           = 'off';


%% ========== Initializations ========== %%
% Here we initialize all classes we will need in our program

% Plotter accumulates all functions for plotting the results
objPlotter = Plotter();
% Reader contains methods for data reading from JSON files and its
% transformation to a format used in program (JSON=> struct)
objReader  = Reader('accelPath', 'accel.json', 'loggerPath', 'angles.json', 'isPrintable', 0);
% Convertor accumulates all the methods for convertion between euler angles
% and quaternions and inversely. Additionally, this method has the function
% to convert acceleration from local CS to global CS.
objConvertor = Convertor();


%% ========== Read Logs ========== %%
objReader.fReadAccel(); % Reads acceleration from JSON
accel = objReader.accel(); % Takes data from the property of the class.
objReader.fReadAngles(); % Reads angles from JSON
anglesLogger = objReader.anglesLogger; % Takes data from the property of the class.
% for s=1:length([accel.timestamp])
%     accel(s).timestamp = accel(s).timestamp * 1e6;
%     anglesLogger(s).timestamp = accel(s).timestamp;
% end
L1 = length(accel);
L2 = length(anglesLogger);

% Apply filters: my style (Oleksiy Grechnyev)
if strcmpi(settings.filterFlag, 'on')
    display('Using Butterworth filter.');
    % This is how I would use filters
    % No idiotic pieces, the whole vector is processed in one go
    % Since filter (unlike filtfilt) is strictly casual
    % This can be done in real time by processing each input packet in turn
    % in the C++ code without any delays of 8 or 24 or anything like that    
    % Filter coefficients
    [b, a] = butter(settings.filterOrder, (2 * settings.cutoffLow)/(1/settings.samplePeriod), 'low' ); 
    display('Filter coefficients :');
    display(a);
    display(b);
else
    display('Using no filters.');
end


%% Angles filtering but for Android only
anglesLoggerFilt = anglesLogger;

figN = 2;


%% GENERAL CYCLE %%
if strcmpi(settings.debugFlag, 'on')
     fileLog1 = fopen('readLog.dat', 'w');
     fileLog2 = fopen('procLog.dat', 'w');
     fprintf(fileLog1, '   t  :  tStamp  isS:    ax         ay         az           a     :    pitch       roll       yaw \n');
     fprintf(fileLog2, '   t  :  tStamp  isS:    ax         ay         az           a     :    pitch       roll       yaw \n');
end

accGlob = struct([]);

stationary = zeros(L1,1);
angZ       = zeros(L1,1);
acMod      = zeros(L1,1);
acModGlob3 = zeros(L1,1);
% acModGlob2 = zeros(L1,1);

for t = 1:L1
    %% ========== Step Detection ========== %%
    % Log read data: passed successfully
    acMod(t) = sqrt(accel(t).x^2 + accel(t).y^2 + accel(t).z^2);
    
     
    
    %% ========== AHRS Correction ========== %%
    % Here we initialize the property "angles of an object objConvertor with the angles detected by the device"
    objConvertor.angles = [ anglesLoggerFilt(t).x;...
                            anglesLoggerFilt(t).y;...
                            anglesLoggerFilt(t).z]';                       
    
    %% ========== From local to Global ========== %%  
    % Convert from Euler angles to quaternion
    objConvertor.quaternion = objConvertor.fGetQuaterionFromAngles();
    
    % Converting acceleration from local CS to global CS
    accGlobal = objConvertor.fFromLocalToGlobal([accel(t).x; accel(t).y; accel(t).z]');
    
    % Transformation from RIGHT-HAND TO LEFT-HAND coordinate system
%     accGlobal(2) = -accGlobal(2);
    
    % Logged global accel and processed angles
    acModGlob3(t) = sqrt(accGlobal(1)^2 + accGlobal(2)^2 + accGlobal(3)^2);
%     acModGlob2(t) = sqrt(accGlobal(1)^2 + accGlobal(2)^2);
    accGlob(t).x  = accGlobal(1);
    accGlob(t).y  = accGlobal(2);
    accGlob(t).z  = accGlobal(3);
    
 end   


%% Apply the filter
accGlobal_filt   = struct([]);
if strcmpi(settings.filterFlag, 'on')    
    temp = filter(b, a, [accGlob.x]);
    for t=1:L1
        accGlobal_filt(t).x = temp(t);
    end
    temp = filter(b, a, [accGlob.y]);
    for t=1:L1
        accGlobal_filt(t).y = temp(t);
    end
    temp = filter(b, a, [accGlob.z]-1);
    for t=1:L1
        accGlobal_filt(t).z = temp(t)+1;
    end
else
    accGlobal_filt = accGlob;
end


acAbs_Glob3_after = zeros(L1, 1);
% acAbs_Glob2_after = zeros(L1, 1);
for t=1:L1
    %acAbs_Glob3_after(t) = sqrt(sum((accGlobal_filt(t).x)^2 + ...
    %                                (accGlobal_filt(t).y)^2 + ...
    %                                (accGlobal_filt(t).z)^2))^2;
                                
    acAbs_Glob3_after(t) = sqrt((accGlobal_filt(t).x)^2 + ...
                                    (accGlobal_filt(t).y)^2 + ...
                                    (accGlobal_filt(t).z)^2);
                                
end


% Find steps
stationary3 = acAbs_Glob3_after < settings.stationaryIndicator3;
% stationary2 = acAbs_Glob2_after < settings.stationaryIndicator2;

% Write the logs
for t=1:L1
    if strcmpi(settings.debugFlag, 'on')
          fprintf(fileLog1, '%5d : %10.6f %1d: ', t, accel(t).timestamp, stationary3(t));
          fprintf(fileLog1, '%10.6f %10.6f %10.6f %10.6f : ', accel(t).x, accel(t).y, accel(t).z, acMod(t));
          fprintf(fileLog1, '%10.6f %10.6f %10.6f\n', anglesLogger(t).x, anglesLogger(t).y, anglesLogger(t).z);
          
         fprintf(fileLog2, '%5d : %10.6f %1d: ', t, accel(t).timestamp, stationary3(t));    
         fprintf(fileLog2, '%10.6f %10.6f %10.6f %10.6f : ', accGlobal(1), accGlobal(2), accGlobal(3), acModGlob3(t));
         fprintf(fileLog2, '%10.6f %10.6f %10.6f\n', anglesLoggerFilt(t).x, anglesLoggerFilt(t).y, anglesLoggerFilt(t).z);
    end
end

%% ========== ZUPT ========== %%
%Zero-velocity detection is a vital part in inertial navigation system. 
%Because inertial sensors are subject to drift, if periods of stationarity 
%is not detected from time to time, errors in acceleration would be integrated 
%in to velocity and position that lea1ds to drastic drift. Zero-velocity 
%provides the required information to reset velocity.

%ZUPT utilizes data from inertial sensor alone. It assumes that when the
%sensor is stationary (reading is 0), velocity is zero and angular rate is 0
%as well. One concern is that if the accelerometer is moving at a constant speed,
%the algorithm would misjudge the motion as stationary.
% But based on our practice, since the accelerometer is very sensitive
%to accelerations, or, forces, and also because walking is a rather complex
%course of acceleration and deceleration, the detection of zero velocity 
%never failed because of misjudgment. 
%There are times that motion detection threshold was not set properly which 
%led to misjudging.

if strcmpi(settings.debugFlag, 'on')
     fileLog3 = fopen('XY_Log.dat', 'w');
     fprintf(fileLog3, '   t  :  tStamp    :     x          y\n');
end

finalTime = accel(end).timestamp;
timeStepN = ceil(finalTime / settings.t_step);
coordsXY = zeros(timeStepN, 2);
coordsXY(1,1) = set(1);    coordsXY(1,2) = set(2);
coordsIndex = 2;

vel = struct([]);
vel(1).x = 0;       vel(1).y = 0;       %  vel(1).z = 0;
pos = struct([]);
pos(1).x = set(1);  pos(1).y = set(2);  %  pos(1).z = 0;
pos(1).timestamp = accel(1).timestamp;

integralAcc = struct([]);
integralAcc(1).x = accGlobal_filt(1).x;
integralAcc(1).y = accGlobal_filt(1).y;
for t = 2:L1
    integralAcc(t).x = integralAcc(t-1).x + accGlobal_filt(t).x;
    integralAcc(t).y = integralAcc(t-1).y + accGlobal_filt(t).y;
end

%% ========== Plotting Map ========== %%
% Plots the map of the office (coordinates in pixels)
filename='idiot';
objPlotter.fig = objPlotter.fPlotRoomPixels(show, filename); 

for t = 1:L1
    if t>1
     deltaT = accel(t).timestamp - accel(t-1).timestamp;
    
     if (stationary3(t) == 1) 
        % Velocity Reset
        pos(t).x = pos(t-1).x; 
        pos(t).y = pos(t-1).y;
        pos(t).timestamp = accel(t).timestamp;
     else
        %% Coordinate axis transformation to axis of the map
        if anglesLoggerFilt(t).z > 0
            ang = anglesLoggerFilt(t).z - 180;
        else
            ang = anglesLoggerFilt(t).z + 180;
        end
        
        dist = settings.userAverageVelocity * deltaT;
        addX = dist * sin(degtorad(ang));
        addY = dist * cos(degtorad(ang));
        
        pos(t).x = pos(t-1).x + addX; 
        pos(t).y = pos(t-1).y + addY;
        pos(t).timestamp = accel(t).timestamp;
     end
    end
    
    if strcmpi(settings.debugFlag, 'on')
             fprintf(fileLog3, '%5d : %10.6f : %10.6f %10.6f\n', t, accel(t).timestamp, pos(t).x, pos(t).y);
    end
    
    % If it is time to show the position, then
    if settings.t_show - accel(t).timestamp < 0
        % Plotter itself
        coordsXY(coordsIndex,1) = pos(t).x;
        coordsXY(coordsIndex,2) = pos(t).y;
        objPlotter.fPlotSimpleApproach([pos(t).x, pos(t).y]/pixelSize, ...
            [coordsXY(coordsIndex-1,1), coordsXY(coordsIndex-1,2)]/pixelSize);
        
        
        
        % This is done to draw a line on the plot
        settings.t_show = settings.t_show + settings.t_step;
        coordsIndex = coordsIndex + 1;
    end
end

if strcmpi(settings.debugFlag, 'on')
     fclose(fileLog3);  
     fclose(fileLog1);
     fclose(fileLog2);
end
