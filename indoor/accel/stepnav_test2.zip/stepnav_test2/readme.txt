1. Input files : in_acc.txt, in_ang.txt

2. Acceleration after Butterworth filter: out_afilt.txt

3. Step detector data and flags: out_stepdetect.txt

4. Inner positions (at inner steps only, can be reverted) : out_innerpos.txt

5. Outer positions, as returned by the navigator: out_pos.txt
