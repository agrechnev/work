classdef INCLUDER
    %Here you find the files necessary to be included in the project
    methods (Access = public, Static)
        function obj = INCLUDER()
            addpath([pwd, '\beaconLogs\']);
            addpath([pwd, '\mapFiles\']);
            addpath([pwd, '\jsonlab\']);                    
        end
    end           
end

