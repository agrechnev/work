classdef CORRECTOR
%% Author:
%  Feliks Sirenko, sirenkofelix@gmail.com
% Eugene Chervonyak
% Alexey Roienko, a.roienko@it-jim.com
%% Owner:
%  IT-Jim Company
%% Last update:
%  21/05/17
%% Class definition
%CHECKER The class contains methods who check the correctness of a trajectory 
% Is it within the map limitations?
% Does the trajectory crosses the wall?
% If the trajectory is somewhere in the restricted zone, then fMeshCorrection method brings the trajectory to normal state
%% Public properties
    
    methods (Static, Access = public)
        function [xy2] = fCorrectIfIsNotOnMap(image, xy2, pix)
            %% fISONMAP - the function checks, if the current point is on the map
            % And if it is not, then it fixes this by shifting it to within the map
            % Example : xy2 = [20 -2] => Correction => xy2 = [20 1]
            % INPUT: image - map of the builing (floor, office etc.)
            %        xy2 - array of current point coordinates [x(i) y(i)]
            % OUTPUT:
            %        xy2 - correctedCoordinates of current point
            xy2 = [xy2(1) -xy2(2)] / pix;
            if xy2(1) < 1
                xy2(1) = 1;
            end
            if xy2(2) < 1
                xy2(2) = 1;
            end
            [y_length, x_length] = size(image);
            if xy2(1) > x_length
                xy2(1) = x_length;
            end
            if xy2(2) > y_length
                xy2(2) = y_length;
            end
            
            xy2 = [xy2(1) xy2(2)] * pix;
        end
        function correctedXY = fMeshCorrector(rawXY, stepsXY, mapHeight, maskTable)
        %% Function provides coordinates correction using "masktable.out" file
        %  which is based on mesh representation of navigation area.
        %% INPUT:
        %  rawXY     - vector, 1x2, raw values of estimated coordinates, in meters, (X,Y)
        %  stepsXY   - vector, 1x2, values of mesh steps along two axes, in meters (X, Y)
        %  mapHeight - height (Y axis direction) of an area covered by navigation system
        %  maskTable - vector, 1xN, contains indecies for transformation of
        %  mesh vertices according to the map mask
        %% OUTPUT:
        %  correctedXY - vector, 1x2, corrected values of estimated coordinates, in meters, (X,Y)
            qX = round(rawXY(1) / stepsXY(1));
            qY = round(rawXY(2) / stepsXY(2));

            % Find number of raws in mesh grid
            Ny = round(mapHeight / stepsXY(2)) + 1;

            % Then index in 1D maskTable is ...
            index = qX*Ny + qY;

            %% If mesh vertex should not be corrected...
            if maskTable(index+1) == index
                correctedXY(1) = qX * stepsXY(1);
                correctedXY(2) = qY * stepsXY(2);    
            else
                %% If the correction is necessary ...
                qX = floor(maskTable(index+1) / Ny);
                qY = maskTable(index+1) - qX*Ny;

                correctedXY(1)  = qX * stepsXY(1);
                correctedXY(2)  = qY * stepsXY(2);    
            end
        end
        function output = fIsInAllowedRegion(image, xy, pix)
        %% The function is not commented, because it will be changed
            xy = ceil([xy(1) xy(2)]/pix);
            x = xy(1); y = xy(2);
            if image(y, x) == 0
            % Step one (Find the first white pixel)
                delt_x = 2; delt_y = 2; dist = 0;
                while (dist == 0)
                    for horiz = x - delt_x : x + delt_x
                        for vert = y - delt_y : y + delt_y
                            if vert > 0 && horiz > 0 && horiz < length(image(1,:)) && vert < length(image(:,1))
                                if image(vert, horiz) == 1
                                    dist = sqrt((horiz - x)^2 + (vert - y)^2);
                                    output = [horiz,vert] * pix;
                                    break;
                                end
                            end
                        end
                        if dist ~= 0
                            break;
                        end
                    end
                   delt_x = delt_x + 2; delt_y = delt_y + 2; 
                end
                % Step two (Find minimum distance)
                for i = horiz - 2 * delt_x : horiz + 2 * delt_x
                    for j = vert - 2 * delt_y : vert + 2 * delt_y
                        if j > 0 && i > 0 && i < length(image(1,:)) && j < length(image(:,1))
                            if image(j, i) == 1
                                temp = sqrt((i - x)^2 + (j - y)^2);
                                if temp < dist
                                    dist = temp;
                                    output = [i,j] * pix;
                                end 
                            end
                        end
                    end
                end
            else
                output = xy * pix;  
            end
        end
    end
end