classdef Plotter < handle
    %PLOTTER Summary of this class goes here
    %   Detailed explanation goes here  
    properties (Access = private, Constant)
        prevCoords = [0 0];
    end
    
    methods (Access = public, Static) 
        function fShowRSSIMap(RSSI, name)
            
            %% Plotting the data
            figure('units','normalized','outerposition',[0 0 1 1])
            hold on;
            timestamps = RSSI(:,1)';  
            hold on;
            for i = 1:length(timestamps)
                    plot([timestamps(i) timestamps(i)], [0 14], 'k:');
            end
                                % Depicting points for packets available
            sizeRSSI = size(RSSI);
            for beac = 2 : sizeRSSI(2) % iterate over beacons (starts from 2 because the first column in time)
                for read = 1 : sizeRSSI(1) % iterate over readings of a beacon 
                    if RSSI(read, beac) ~=0
                        scatter(RSSI(read,1) , beac - 1, 'filled', 'MarkerEdgeColor',[0 .5 .5], 'MarkerFaceColor',[0 .7 .7]);
                        text(RSSI(read,1), beac - 1 + 0.3, num2str(roundn(RSSI(read,beac), -1)) , 'Color', 'black', 'FontSize', 8) ;
                    end                     
                end
            end    
            title(['\color{magenta}\fontsize{16}' name]);
            T = get(gca,'tightinset');
            set(gca,'position',[T(1) T(2) 1-T(1)-T(3) 1-T(2)-T(4)]);
            xlabel('Time, sec.');
            ylabel('Beacons number in json-file)');
            ax = gca;
            ax.XTick = ceil(min(timestamps)) - 1 : ceil(max(timestamps));
            ax.YTick = 0:sizeRSSI(2);
            xlim([(ceil(min(timestamps)) - 1) ceil(max(timestamps))]);
            ylim([0 sizeRSSI(2)]);
            ax.YGrid = 'on';
            ax.GridLineStyle = '--';
            ax.GridAlpha = 0.5;
            box on;     
            pause();
            close;
        end
        
        function fShowRSSITimeScale (RSSI, name)
                figure('units','normalized','outerposition',[0 0 1 1])
                hold on;

                for i=2 : length(RSSI(1,:))
                    plot(RSSI(:,1), RSSI(:,i), 'LineWidth' , 3, 'DisplayName' , ['BEAC' int2str(i-1)] );
                end
                legend('Location','northeast');
                title(['\color{magenta}\fontsize{16}' name]);
                T = get(gca,'tightinset');
                set(gca,'position',[T(1) T(2) 1-T(1)-T(3) 1-T(2)-T(4)]);
                xlabel('Time, sec.');
                ylabel('Beacons number in json-file)');
                ax = gca;
                ax.XTick = 0:ceil(max(RSSI(:,1)));
                ylim([-100 -60]);
                xlim([0 ceil(max(RSSI(:,1)))]);
                ax.YGrid = 'on';
                ax.GridLineStyle = '--';
                ax.GridAlpha = 0.5;
                box on;
                
                pause();
                close;
        end
        
        function PlotMap(varargin)
            figure('units','normalized','outerposition',[0 0 1 1])
            hold on;
            set(gca,'XTick',[]); 
            set(gca,'YTick',[]);
            imshow(varargin{1,1}); 
            title(varargin{1,2}.title, 'FontSize',16);
            axis image
            hold on;   
            xlabel(['Processing ' varargin{1,3}.name ' ...'], 'FontSize',16 );
            pix = varargin{1,4};
            beac = varargin{1,5};
           
            for i = 1: length(beac)
            plot(beac{1,i}.x / pix, beac{1,i}.y / pix, 'LineStyle', 'none', 'Marker', 'o', 'MarkerFaceColor', 'yellow', 'markersize',25,'DisplayName', strcat('B', i));
            text(beac{1,i}.x / pix - 30, beac{1,i}.y / pix, ['B' int2str(i)], 'FontSize', 14);
            end
            hold on;            
        end
        
        function fPlotCirclesRSSI(userCoords , BeacParam, distToUser, pix, mapImage ) 
            %% Plot Selected Beacons
            XY = zeros(length(BeacParam),2);
            
            for i = 1 : length(BeacParam)
                XY(i,1) = BeacParam{1,i}.x;
                XY(i,2) = BeacParam{1,i}.y;
            end
            
            selBeac = plot(XY(:,1)/pix, XY(:,2)/pix,...
              'LineStyle', 'none', 'Marker', 'o', 'MarkerFaceColor', 'r', 'markersize',30);
           
            %% Plot RSSI of Selected Beacons 
            captions = zeros(length(BeacParam),1);
            
            for i = 1:length(BeacParam)
                captions(i,1) = BeacParam{1,i}.RSSI;
            end
        
            texts1 = text(XY(:,1)/pix - 40,  XY(:,2) / pix, ...
                         int2str(captions(:,1)), 'FontSize', 14);

            circle = zeros(length(distToUser), 1);
            for i = 1 : length(distToUser)
                ang=0:0.01:2*pi; 
               	xp=distToUser(i) * cos(ang);
               	yp=distToUser(i) * sin(ang);
               	circle(i) = plot((XY(i,1) + xp)/pix, (XY(i,2) + yp) / pix);
            end 
            plot(userCoords(1)/pix, userCoords(2)/pix, 'LineStyle', 'none', 'Marker', 'o',...
                'MarkerFaceColor', 'b', 'markersize', 20);
            texts2 = text(userCoords(1)/pix-40,  userCoords(2)/pix, 'ML', 'FontSize', 10);
            xlim([1 length(mapImage(1, :, 1))]);
            ylim([1 length(mapImage(:, 1, 1))]);
            
            pause();
            
            delete(selBeac);
            delete(circle);
            delete(texts1);  delete(texts2);
        end
        
        function fPlotCirclesDIST(userCoords , BeacParam, distToUser, pix, mapImage ) 
            %% Plot Selected Beacons
            XY = zeros(length(BeacParam),2);
            
            for i = 1 : length(BeacParam)
                XY(i,1) = BeacParam{1,i}.x;
                XY(i,2) = BeacParam{1,i}.y;
            end
            
            selBeac = plot (XY(:,1) / pix, XY(:,2) / pix,...
                                    'LineStyle', 'none', 'Marker', 'o', 'MarkerFaceColor', 'r', 'markersize',30);
           
            %% Plot RSSI of Selected Beacons 
            captions = zeros(length(BeacParam),1);
            
            for i = 1 : length(BeacParam)
                captions(i,1) = BeacParam{1,i}.DIST;
            end
        
            texts = text(XY(:,1)/pix-40, XY(:,2)/pix,...
                           num2str(captions(:,1)), 'FontSize', 14);
            
            circle = zeros(length(distToUser.DIST), 1);
            for i = 1 : length(distToUser.DIST)
                ang=0:0.01:2*pi; 
               	xp=distToUser.DIST(i) * cos(ang);
               	yp=distToUser.DIST(i) * sin(ang);
               	circle(i) = plot((XY(i,1) + xp)/pix, (XY(i,2) + yp) / pix);
            end 
            plot(userCoords(1)/pix, userCoords(2)/pix, 'LineStyle', 'none', 'Marker', 'o', 'MarkerFaceColor', 'b', 'markersize', 20);
            xlim([1 length(mapImage(1, :, 1))]);
            ylim([1 length(mapImage(:, 1, 1))]);
            pause(0.01);
            delete(selBeac);
            delete(circle);
%            delete(coords);
            delete(texts);
        end
        
        function fPlotPositions(Coords , pix)
            plot(Coords.x/pix, Coords.y / pix, 'LineStyle', 'none',...
                'Marker', 'o', 'MarkerFaceColor', 'm', 'markersize', 20);
            texts = text(Coords.x/pix-40,  Coords.y/pix, 'UA', 'FontSize', 10);
            pause(0.5);
            delete(texts);
        end
    end
end
