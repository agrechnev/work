classdef LATERATION   
    methods (Access = public, Static)      
        function [output, result] = fGetNBeacons(readings, numb, logBeaconsN, indicator)
                if nnz(readings) > numb
                    tempArray = readings;
                    tempArray(tempArray == 0) = -999;
                    [A, B] = sort(tempArray, 'descend');
                    output.RSSI   = A(1:numb);
                    output.beacNO = B(1:numb);
                    % Looking for the same RSSI values from two different
                    % beacons starting from the last beacon in triplet
                    for n=numb+1:length(tempArray)
                        if A(n)~=A(numb)
                            if n~=numb+1                                
                                output.RSSI(numb)  = A(n-1);
                                output.beacNO(numb)= B(n-1);
                            end
                            break;
                        end
                    end
                    result = true;
                    if indicator
                        str = [num2str(logBeaconsN.beacon1) '  ' num2str(logBeaconsN.beacon2) '  '...
                               num2str(logBeaconsN.beacon3)];
                        disp(['Beacons, selected by SDK are : ' str]);
                        disp(['Selected beacons are :         ' int2str(output.beacNO)]);
                     end
                else
                    disp(['Number of readings is less than ' num2str(numb) '!']);
                    output = NaN;
                    result = false;
                end            
        end
        
        function [output, result] = fGetNDist(readings, numb, indicator)
                if nnz(readings) > numb
                    tempArray = readings;
                    tempArray(tempArray <= 0.3 ) = 999;
                    [A, B] =sort(tempArray, 'ascend');
                    output.DIST = A(1:numb);
                    output.beacNO = B(1:numb);
                    result = true;
                    if indicator
                        disp(['Selected beacons are : ' int2str(output.beacNO)]);
                    end
                else
                    output = NaN;
                    result = false;
                end            
        end
        
        function output = fRssi2Dist(beacons)
        	beaconsN = length(beacons);
            output   = zeros(1, beaconsN);
            for bN = 1:beaconsN
                if beacons{bN}.RSSI > beacons{bN}.txpower
                    output(bN) = 1;
                else
                    output(bN) = 10^(0.1*(beacons{bN}.txpower - beacons{bN}.RSSI) / beacons{bN}.damp);
                end
            end
       end
        
        function estRXCoords = fTrilateration(beacons, DistMatrix, userH)
            distN = length(DistMatrix);
            beaconsN = length(beacons);

            if (distN ~= beaconsN)
                error('Number of reference points and distances are different!');
            elseif (distN ~= 3)||(beaconsN ~= 3)
                error('Number of reference points and/or distances differs from 3!');
            else
                RefPoints = zeros(3,beaconsN);
                for bN=1:beaconsN
                    RefPoints(1,bN) = beacons{bN}.x;
                    RefPoints(2,bN) = beacons{bN}.y;
                    RefPoints(3,bN) = beacons{bN}.z - userH;
                end

                %% Step 1 - Calculate A, B, C, Xs and Ys coefficients for trilateration formulas
                A = RefPoints(1,1)^2 + RefPoints(2,1)^2 - DistMatrix(1)^2;
                B = RefPoints(1,2)^2 + RefPoints(2,2)^2 - DistMatrix(2)^2;
                C = RefPoints(1,3)^2 + RefPoints(2,3)^2 - DistMatrix(3)^2;

                Xs_array(1) = RefPoints(1,1) - RefPoints(1,3);
                Xs_array(2) = RefPoints(1,2) - RefPoints(1,1);
                Xs_array(3) = RefPoints(1,3) - RefPoints(1,2);

                Ys_array(1) = RefPoints(2,1) - RefPoints(2,3);
                Ys_array(2) = RefPoints(2,2) - RefPoints(2,1);
                Ys_array(3) = RefPoints(2,3) - RefPoints(2,2);

                %% Step 2 - Calculate Receiver X ...
                num(1)   = A*Ys_array(3) + B*Ys_array(1) + C*Ys_array(2);
                denom(1) = 2*(RefPoints(1,1)*Ys_array(3) + ...
                              RefPoints(1,2)*Ys_array(1) + ...
                              RefPoints(1,3)*Ys_array(2));
                estRXCoords(1) = num(1)/denom(1);

                %% ... and Y coordinates
                num(2)   = A*Xs_array(3) + B*Xs_array(1) + C*Xs_array(2);
                denom(2) = 2*(RefPoints(2,1)*Xs_array(3) + ...
                              RefPoints(2,2)*Xs_array(1) + ...
                              RefPoints(2,3)*Xs_array(2));
                estRXCoords(2) = num(2)/denom(2);     
            end
        end 
        
        function [N1, N2] = fMultilateration(beacons, DistMatrix, userH)
            beaconsN = length(beacons);
            distN = length(DistMatrix);

            if (distN ~= beaconsN)
                error('Number of reference points and distances are different');
            end

            A = zeros(beaconsN, 4);
            b = zeros(beaconsN, 1);
            for bN=1:beaconsN
                x = beacons{bN}.x; 
                y = beacons{bN}.y;
                z = beacons{bN}.z - userH;

                A(bN, :) = [1 -2*x  -2*y  -2*z]; 
                b(bN, 1) = DistMatrix(bN)^2-x^2-y^2-z^2;
            end

            if beaconsN == 3
                Xp = A\b;  % Gaussian elimination

                xp = Xp(2:4, :);
                Z = null(A,'r');
                z = Z(2:4, :);
                if rank(A)==3
                    %Polynom coeff.
                    a2 = z(1)^2 + z(2)^2 + z(3)^2 ;
                    a1 = 2*(z(1)*xp(1) + z(2)*xp(2) + z(3)*xp(3))-Z(1);
                    a0 = xp(1)^2 +  xp(2)^2+  xp(3)^2-Xp(1);
                    p = [a2 a1 a0];
                    t = roots(p);

                    %Solutions
                    N1 = Xp + t(1)*Z;
                    N2 = Xp + t(2)*Z;
                end

            elseif beaconsN > 3
                % Solution without Weights Matrix
                Xpdw = pinv(A)*b; 
                % the matrix  inv(A'*A)*A' or inv(A'*C*A)*A'*C or pinv(A)
                % depends only on the reference points
                % it could be computed only once
                N1 = Xpdw;
                N2 = N1;
            end

            N1 = real(N1(2:4, 1));
            N2 = real(N2(2:4, 1));
        end
    end    
end

