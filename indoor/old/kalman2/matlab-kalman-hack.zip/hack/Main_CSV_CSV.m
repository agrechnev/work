% This script compares the positioning made by User application and by
% script developed by IT-Jim company.

% This version is hacked by OLEKSIY GRECHNYEV

% Initial data are *.csv files from user application.
% The main task of the script is to compare the position
% obtained the User application and by the script.

clc;
close all;
clear;

%% Include folders
INCLUDER();

%% Read INI files, map parameters and mask parameters, mask and map
[INI, mapParams, beaconsParams, beaconsID, mapImage, mapMask] = ...
    READER.fReadAllSettings('config_CSV_CSV.ini');

%% Reading data from CSV file
dirContentCSV = dir([pwd INI.pathes.logsCSV]);
%% Separating the BLE and POSITION files
positionFiles    = struct('fileName','');
posFilesIndex    = 0;
bleFiles         = struct('fileName','');
bleFilesIndex    = 0;
trilatFiles      = struct('fileName','');
trilatFilesIndex = 0;
for file = INI.settings.f_start : length(dirContentCSV)     %% Process all files in folder "CSVLogs"
    if strcmpi(dirContentCSV(file).name(1:3), 'ble')
        bleFilesIndex = bleFilesIndex + 1;
        bleFiles(bleFilesIndex).name = dirContentCSV(file).name;        
    end
    if strcmpi(dirContentCSV(file).name(1:3), 'pos')
        posFilesIndex = posFilesIndex + 1;
        positionFiles(posFilesIndex).name = dirContentCSV(file).name;        
    end
    if strcmpi(dirContentCSV(file).name(1:3), 'tri')
        trilatFilesIndex = trilatFilesIndex + 1;
        trilatFiles(trilatFilesIndex).name = dirContentCSV(file).name;
    end
end

%% Finding pairs of the BLE and POSITION files
if (bleFilesIndex>0) && (posFilesIndex>0) && (posFilesIndex>0) && ...
   (bleFilesIndex==posFilesIndex) && (bleFilesIndex==trilatFilesIndex)
    for bleFile = 1:bleFilesIndex
        for posFile = 1:posFilesIndex
            if strcmpi(positionFiles(posFile).name(end-11:end), bleFiles(bleFile).name(end-11:end))
                break;
            end
            if posFile == posFilesIndex
                error(['There is no corresponding Position file for BLE file ' ...
                        bleFiles(bleFile).name(end-11:end)]);
            end
        end
    end
else
    error('Check the number and correspondence of BLE and POS files!');
end
disp('All BLE files have corresponding Position files');


%% ======================================================================= %
% ========================= MAIN LOOP FOR FILES ========================= %
% ======================================================================= %
for bleFile = 1:bleFilesIndex
    %% Reading files and transforming them to an appropriate format
	bleData = READER.fReadBleCSV([pwd INI.pathes.logsCSV '\' bleFiles(bleFile).name], beaconsID);
    for posFile = 1:posFilesIndex
        if strcmpi(positionFiles(posFile).name(end-11:end), bleFiles(bleFile).name(end-11:end))
            posData    = READER.fReadPosCSV([pwd INI.pathes.logsCSV '\' positionFiles(posFile).name]);
            trilatData = READER.fReadTrilatCSV([pwd INI.pathes.logsCSV '\' trilatFiles(posFile).name], beaconsID);
            break;
        end
    end
    
%     if INI.debug.debugInfo
%     	Plotter.fShowRSSIMap(bleData, 'Raw Data');  % Show RSSI map with raw data
%     end
    packetsNumber = length(bleData(:,1));
 

%    Oleksiy Grechnyev   print raw RSSI data 
    fileID = fopen('out/raw.out', 'w');
    for pN = 1:packetsNumber
        for i = 1:size(bleData, 2)
            fprintf(fileID, '%13.8f ', bleData(pN,i));
        end    
        fprintf(fileID, '\n');
    end
    fclose(fileID);
% End Oleksiy Grechnyev 
    % ======================= RSSI KALMAN FILTRATION (OPTIONAL) =========================%
    if INI.FiltersCorrectors.RSSI_filter
%         KalmanFilteredData = bleData; % Just initialization
%         bleData(:, 5:8) = 0;
%         bleData(:, 9:end) = 0;
         P = [100 0; 0 100];     % covariance matrix         
         Q = [0.001 0; 0 0.001]; % model error covariance [0.002 0; 0 0.002]
         R = 0.1;                % measurement error covariance 0.11
        
         objKalman = KalmanFilterRSSI ('P_init', P,...
                                       'Q', Q,...
                                       'R', R,...
                                       'beacNumb', INI.settings.beaconsN,...
                                       'timeout1', 1.5,...
                                       'timeout2', 5);

         KalmanFilteredData = zeros(size(bleData));
         for pN=1:packetsNumber
             if pN==1
                 dt = 0;
             else
                 dt = bleData(pN,1)-bleData(pN-1,1);
             end
             KalmanFilteredData(pN, 1) = bleData(pN,1);
             KalmanFilteredData(pN, 2:end) = objKalman.FilterMany(dt, bleData(pN,2:end));
         end
    else 
        KalmanFilteredData = bleData;
    end
    
%    Oleksiy Grechnyev   print filltered RSSI data 
    fileID = fopen('out/filtered.out', 'w');
    for pN = 1:packetsNumber
        for i = 1:size(KalmanFilteredData, 2)
            fprintf(fileID, '%13.8f ', KalmanFilteredData(pN,i));
        end    
        fprintf(fileID, '\n');
    end
    fclose(fileID);
% End Oleksiy Grechnyev 
% ================== PLOT THE RESULTS OF FILTRATION (OPTIONAL) ======================%
%%
	if INI.debug.debugInfo
%     	Plotter.fShowRSSIMap(KalmanFilteredData, 'Kalman Filter RSSI');
%         Plotter.fShowRSSITimeScale(KalmanFilteredData, 'Kalman Filter RSSI');
    end
    
    f_content = dir([pwd INI.pathes.logsCSV]); 
%    Plotter.PlotMap(mapImage,...            % Plot MAP      
%                    mapParams,...
%                    bleFiles(bleFile),...
%                    mapParams.pixelSize,...
%                    beaconsParams);
                
    if INI.FiltersCorrectors.PKalman_filter % If PKalman is used
        P = [100 0;...         % How sure I am in initial position
             0 100];
        Q = [0.001 0;...       % What mistake can I make when predicting a new one position
             0 0.001];
        R = eye(3) * 0.1; % Distribute weights between the model and the measurements

        objKalmanP = KalmanFilterPModel('P', P, 'Q', Q, 'R', R);  % PModel of Kalman
    end
    
    showTime = 1;
    posTimeIndex = 2;
    
    fileS3=fopen('out/strongest3.out', 'w');
    fileSR=fopen('out/strongestRssi.out', 'w');
    filePos=fopen('out/pos.out', 'w');
    fileTril=fopen('out/trilat.out', 'w');
    for pN = 1:packetsNumber
        [SelectedBeacons, isSuccessfully] = LATERATION.fGetNBeacons(...
             KalmanFilteredData(pN, 2:end), INI.Positioning.laterat_beacNO,...
             trilatData(pN), INI.debug.debugInfo);
         
         % Oleksiy Grechnyev log nearest beacons
         fprintf(fileS3, '%13.8f ', bleData(pN,1)); % timestamp
         % SelectedBeacons
         for bNum = SelectedBeacons.beacNO
             fprintf(fileS3, '%2d ',bNum); % Beacon number
         end
         fprintf(fileS3, '\n'); 
         %  log 3 strongest RSSIs used for trilat
         fprintf(fileSR, '%13.8f ', bleData(pN,1)); % timestamp
         for rssi = SelectedBeacons.RSSI
             fprintf(fileSR, '%13.8f ',rssi); % RSSI
         end
         fprintf(fileSR, '\n'); 
         % End Oleksiy Grechnyev

        if isSuccessfully
            beaconsLaterat = cell(1,INI.Positioning.laterat_beacNO);
            for j=1 : INI.Positioning.laterat_beacNO
                beacon = beaconsParams{1, SelectedBeacons.beacNO(j)};
                beacon.RSSI = SelectedBeacons.RSSI(j);
                beacon.beaconN = SelectedBeacons.beacNO(j);
                beaconsLaterat{j} = beacon; 
            end
            % Here we convert the RSSI to distance 
            distancesLaterat = LATERATION.fRssi2Dist(beaconsLaterat);
            
            % Oleksiy Grechnyev log distances
            fprintf(fileTril, '%13.8f ', bleData(pN,1)); % timestamp
            for dist = distancesLaterat
                fprintf(fileTril, '%13.8f ', dist); 
            end
            fprintf(fileTril, '\n'); 
            % End Oleksiy Grechnyev

            %%
            if strcmpi(INI.Positioning.pos_method, 'Trilateration')
               userCoords  = LATERATION.fTrilateration(beaconsLaterat,...       % Here we obtain user coordinates from the trilateration
                    distancesLaterat, INI.settings.userHeight);
            elseif strcmpi(INI.Positioning.pos_method, 'Multilateration')
               userCoords  = LATERATION.fMultilateration(beaconsLaterat,...       % Here we obtain user coordinates from the trilateration
                    distancesLaterat, INI.settings.userHeight);               
            else
               error('Error in Lateration method');
            end
            
            % Oleksiy Grechnyev log position
            fprintf(filePos, '%13.8f ', bleData(pN,1)); % timestamp
            fprintf(filePos, '%13.8f %13.8f ', userCoords(1), userCoords(2)); 
            fprintf(filePos, '\n'); 
            % End Oleksiy Grechnyev

            %%
            if INI.FiltersCorrectors.PKalman_filter
                userCoords = objKalmanP.FilterByKalman(userCoords,...           % Kalman filtering
                                [beaconsLaterat{1,1}.x beaconsLaterat{1,1}.y],...
                                [beaconsLaterat{1,2}.x beaconsLaterat{1,2}.y],...
                                [beaconsLaterat{1,3}.x beaconsLaterat{1,3}.y]); 
            end
            if INI.FiltersCorrectors.is_on_Map_filter
                userCoords = CORRECTOR.fCorrectIfIsNotOnMap(mapMask,...         % Checks, are User coordinates on the map
                                             [userCoords(1) -userCoords(2)],... % If no, then brings them back on the map
                                              mapParams.pixelSize);
            end
            if INI.FiltersCorrectors.is_BlackPixelFilterRequireed
                userCoords = CORRECTOR.fIsInAllowedRegion(mapMask,...           % Checks, are User coordinates in the allowed region
                                                          userCoords,...        % If not, findes the nearest white pixel and puts the coordinates there
                                                          mapParams.pixelSize);            
            end
            
            if (pN < packetsNumber) && (KalmanFilteredData(pN+1, 1) > showTime)
                if INI.debug.debugInfo
                    str = sprintf('Timestamp is %d', showTime);
                    disp(str);
                    str = sprintf('MatLab coords:  X=%.3f, Y=%.3f', userCoords(1), userCoords(2));
                    disp(str);
                    str = sprintf('UserApp coords: X=%.3f, Y=%.3f\n', posData(posTimeIndex).x, posData(posTimeIndex).y);
                    disp(str);
                end 
                
                %if posData(posTimeIndex).x > 6.1
                %    posData(posTimeIndex).x = 6.1;
                %end
                %if posData(posTimeIndex).x < 0.05
                %    posData(posTimeIndex).x = 0.05;
                %end
%                Plotter.fPlotPositions(posData(posTimeIndex), mapParams.pixelSize);
                posTimeIndex = posTimeIndex + 1;                
                
%                Plotter.fPlotCirclesRSSI(userCoords,...
%                    beaconsLaterat, distancesLaterat, mapParams.pixelSize, mapImage );
                showTime = showTime + 1;
            end            
        end
    end
    fclose(fileS3);
    fclose(fileSR);
    fclose(filePos);
    fclose(fileTril);
%     pause();
end







