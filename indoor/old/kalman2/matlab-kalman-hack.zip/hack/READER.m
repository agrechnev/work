classdef READER
    %READER Summary of this class goes here
    %   Detailed explanation goes here

    methods (Access = public, Static)       
        function [INI, mapParams, beaconsParams, beaconsIdentifiers, mapImage, mapMask] = ...
                 fReadAllSettings(fileSettings)
            INI = READER.fReadINI(fileSettings);
            [mapParams, beaconsParams, beaconsIdentifiers, INI.settings.beaconsN] = READER.fReadMapJSON (INI);
            mapImage = READER.fReadImage(INI.pathes.mapImage);
            mapMask = READER.fReadImage(INI.pathes.maskImage);
        end          
        
        function output = fReadINI(file)
            output = INI('File',file).read();        
        end
        
        function [mapParams, beaconsParams, classifiers, beaconsN] = fReadMapJSON (INI)
            mapParams = READER.fReadJson([pwd, INI.pathes.mapJSON], 'map');
            beaconsParams = READER.fReadJson([pwd, INI.pathes.mapJSON], 'beaconsParams');
            if strcmp(INI.settings.deviceOS , 'Android')
                classifiers = READER.fReadJson([pwd, INI.pathes.mapJSON], 'MAC');
            elseif strcmp(INI.settings.deviceOS , 'iOS')
                classifiers = READER.fReadJson([pwd, INI.pathes.mapJSON], 'MajorMinor');
            else
                error('Wrong OS');
            end
            beaconsN = length(classifiers);
        end
        
        function im = fReadImage(imName)
            if (~isnan([pwd , imName]))
                im  = imread([pwd , imName]);
            end
        end  
        
        function output = fReadLogJSON(INI, dataFromJSON, identifiers)
            beaconsN = length(dataFromJSON);
            indecesN = length(identifiers);
            indeces = zeros(1, indecesN);
            %% Finding beacons order in the log
            if strcmp(INI.settings.deviceOS , 'Android')
                for bN = 1:beaconsN
                    currentMAC = dataFromJSON{bN}{1}.MACaddress;
                    for n=1:indecesN
                        if strcmp(currentMAC, identifiers{n})
                            indeces(n) = bN;
                            break;
                        end
                    end
                end
            elseif strcmp(INI.settings.deviceOS , 'iOS' )
                for bN = 1:beaconsN
                    currentMajorMinor = strcat(int2str(dataFromJSON{bN}{1}.major) , int2str(dataFromJSON{bN}{1}.minor) );
                    for n=1:indecesN
                        if strcmp(currentMajorMinor, identifiers{n})
                            indeces(n) = bN;
                            break;
                        end
                    end
                end
            else
                error('Wrong OS');
            end
            %% Reading RSSI and timestamp values
            rssi = cell(1, indecesN);
            ts   = cell(1, indecesN);
            for bN = 1:indecesN
                if indeces(bN)~=0
                    bNpacks  = length(dataFromJSON{indeces(bN)});
                    rssi{bN} = zeros(bNpacks, 1);
                    ts{bN}   = zeros(bNpacks, 1);
                    for pN = 1:bNpacks
                        if strcmp(INI.settings.deviceOS , 'Android')
                            rssi{bN}(pN) = dataFromJSON{indeces(bN)}{pN}.RSSI;         
                            ts{bN}(pN)   = dataFromJSON{indeces(bN)}{pN}.TimeStamp;   
                        elseif strcmp(INI.settings.deviceOS , 'iOS')
                            rssi{bN}(pN) = dataFromJSON{indeces(bN)}{pN}.rssi;         
                            ts{bN}(pN)   = dataFromJSON{indeces(bN)}{pN}.timestamp;                               
                        end
                    end
                end
            end
            %%%%%%%%%%% Diagnostics methods
             if INI.debug.debugInfo
                for bN=1:INI.settings.beaconsN
                    if indeces(bN)==0
                        disp(['Warning! Beacon #' num2str(bN) ' is absent in the log!']);
                    end
                end
             end  
            %%%%%%%%%%% Converting to an appropriate format         
            j = 1;
            k = 1;
            arrUniqueTimes = [];
            %% Iterate to find the unique timestamps from all beacons
            for i=1 : length(ts)              % Iterate through beacons
                for j=1: length(ts{1,i})      % Iterate through beacon readings
                    if strcmp(INI.settings.deviceOS , 'Android')
                        value = (ceil(ts{1,i}(j,1)/10))/100;  % get time in seconds
                    else
                        value = ceil(ts{1,i}(j,1) * 10) / 10; % get time in seconds
                    end
                    if ~any(abs(value - arrUniqueTimes) < 0.03)     % If time is not in the array
                        arrUniqueTimes(end+1,1) = value;            % add it to an array
                    end
                    j=j+1;
                end
                k=1;        
            end
            arrUniqueTimes = sort(arrUniqueTimes);                  % Sort times
            clear value;
            %% Iterate to fill in the table
            output = zeros(length(arrUniqueTimes), length(ts) + 1);
            output(:,1) = arrUniqueTimes;
            iter = 1;
            
            for i=1 : length(ts)              % Iterate through beacons
                for j=1: length(ts{1,i})      % Iterate through beacon readings
                    if strcmp(INI.settings.deviceOS , 'Android')
                        value.time = ceil(ts{1,i}(j,1)/10)/100;  % get time in seconds
                    else
                        value.time = ceil(ts{1,i}(j,1) * 10) / 10; % get time in seconds
                    end
                    value.rssi = rssi{1,i}(j,1);               % get RSSI
                    value.beacNO = i;                          % get Beacon number
                    
                    for k = iter : length (arrUniqueTimes)     % iterate through the output array
                        if abs(value.time - arrUniqueTimes(k)) < 0.03 % If time of registration matches the time in output array
                            output(k, value.beacNO + 1) = value.rssi; % Fill in the RSSI in the corresponding cell (cell corresponds to beacon number)
                            iter = k;   % As time is sorted, so we can be sure that the next timestamp takes the position after current
                            break;
                        end
                    end
                end
                iter = 1;   % Reset the iteration number when switching to a new beacon data
            end 
        end            
        
        
        function output = fReadBleCSV(filename, identifiers)
            delimiter = ',';
            startRow = 1;
            endRow = inf;
            
            formatSpec = '%f%s%f%f%f%f%[^\n\r]';

            fileID = fopen(filename,'r');
            dataArray = textscan(fileID, formatSpec, endRow(1)-startRow(1)+1,...
                'Delimiter', delimiter, 'HeaderLines', startRow(1)-1,...
                'ReturnOnError', false, 'EndOfLine', '\r\n');
            
            for block=2:length(startRow)
                frewind(fileID);
                dataArrayBlock = textscan(fileID, formatSpec,...
                    endRow(block)-startRow(block)+1, 'Delimiter', delimiter,...
                    'HeaderLines', startRow(block)-1, 'ReturnOnError', false,...
                    'EndOfLine', '\r\n');
                dataArray{1} = [dataArray{1}; dataArrayBlock{1}];
            end
            fclose(fileID);
            
            MajorMinorRSSI = zeros(length(dataArray{1,1}), 4);
            MajorMinorRSSI(:,1) = (dataArray{1,1}(:,1) - dataArray{1,1}(1,1))/1000; % Time
            MajorMinorRSSI(:,2) = dataArray{1,3}(:,1); % Major
            MajorMinorRSSI(:,3) = dataArray{1,4}(:,1); % Minor
            MajorMinorRSSI(:,4) = dataArray{1,6}(:,1); % RSSI
            
            output(1) = 0;
            iterator = 1;
            
            for read = 1:size(MajorMinorRSSI,1)
                if MajorMinorRSSI(read,1) > output(iterator) && MajorMinorRSSI(read,1) - output(iterator) > 0.1
                    iterator = iterator + 1;
                    output(iterator, 1) = MajorMinorRSSI(read,1);
                end
                
                id = strcat(num2str(MajorMinorRSSI(read,2)) , num2str(MajorMinorRSSI(read,3)) );
                
                idLength = size(identifiers);
                for ident = 1:idLength(2)
                    if strcmp(id, identifiers(1,ident))
                        output(iterator, ident + 1) = MajorMinorRSSI(read, 4);
                        break;
                    end
                end
            end
        end
        
        function output = fReadPosCSV(filename)
            delimiter = ',';
            startRow = 1;
            endRow = inf;
            
            formatSpec = '%f%f%f%[^\n\r]';
            
            fileID = fopen(filename,'r');
            dataArray = textscan(fileID, formatSpec, endRow(1)-startRow(1)+1, ...
                'Delimiter', delimiter, 'HeaderLines', startRow(1)-1,...
                'ReturnOnError', false);
            for block=2:length(startRow)
                frewind(fileID);
                dataArrayBlock = textscan(fileID, formatSpec, endRow(block)-startRow(block)+1,...
                    'Delimiter', delimiter, 'HeaderLines', startRow(block)-1,...
                    'ReturnOnError', false);
                for col=1:length(dataArray)
                    dataArray{col} = [dataArray{col}; dataArrayBlock{col}];
                end
            end            
            fclose(fileID);
            
            %posData = table(dataArray{1:end-1}, 'VariableNames', {'timestamp','X','Y'});            
            
            
%             posData = zeros(length(dataArray{1,1}), 3);
%             posData(:,1) = (dataArray{1,1}(:,1) - dataArray{1,1}(1,1))/1000; % Timestamp, to sec.
%             posData(:,2) = dataArray{1,2}(:,1); % X
%             posData(:,3) = dataArray{1,3}(:,1); % Y

            posData = struct('timestamp','', 'x', 0, 'y', 0);
            for t=1:length(dataArray{1,1})
                % Timestamp, to sec.
                posData(t).timestamp = (dataArray{1,1}(t,1) - dataArray{1,1}(1,1))/1000; 
                posData(t).x = dataArray{1,2}(t);
                posData(t).y = dataArray{1,3}(t);
            end
            output = posData;
        end
    
        function output = fReadTrilatCSV(filename, beaconsID)
            startRow = 1;
            endRow = inf;
            
            formatSpec = '%13f%37s%6f%f%[^\n\r]';

            %% Open the text file.
            fileID = fopen(filename,'r');

            %% Read columns of data according to format string.
            % This call is based on the structure of the file used to generate this
            % code. If an error occurs for a different file, try regenerating the code
            % from the Import Tool.
            dataArray = textscan(fileID, formatSpec, endRow(1)-startRow(1)+1, 'Delimiter', '',...
                'WhiteSpace', '', 'HeaderLines', startRow(1)-1, 'ReturnOnError', false);
            for block=2:length(startRow)
                frewind(fileID);
                dataArrayBlock = textscan(fileID, formatSpec, endRow(block)-startRow(block)+1,...
                    'Delimiter', '', 'WhiteSpace', '', 'HeaderLines', startRow(block)-1, 'ReturnOnError', false);
                for col=1:length(dataArray)
                    dataArray{col} = [dataArray{col}; dataArrayBlock{col}];
                end
            end

            %% Remove white space around all cell columns.
            dataArray{2} = strtrim(dataArray{2});

            %% Close the text file.
            fclose(fileID);

            %% Post processing for unimportable data.
            % No unimportable data rules were applied during the import, so no post
            % processing code is included. To generate code which works for
            % unimportable data, select unimportable cells in a file and regenerate the
            % script.

            bNumber = size(beaconsID);
            posData = struct('timestamp','', 'beacon1', 0, 'beacon2', 0, 'beacon3', 0);
            posDataIndex = 1;
            lastTS = -1;
            for t=1:length(dataArray{1,1})                
                currentTS = (dataArray{1,1}(t,1) - dataArray{1,1}(1,1))/1000; 
                if currentTS ~= lastTS
                    beaconCounter = 1;
                    lastTS = currentTS; 
                    posData(posDataIndex).timestamp = lastTS;
                end
                
                for bN=1:bNumber(2)
                    if (dataArray{1,3}(t) == str2double(beaconsID{2,bN})) && ...
                       (dataArray{1,4}(t) == str2double(beaconsID{3,bN}))
                        switch beaconCounter
                           case 1
                               posData(posDataIndex).beacon1 = bN;                               
                           case 2
                               posData(posDataIndex).beacon2 = bN;                               
                           case 3
                               posData(posDataIndex).beacon3 = bN;
                               posDataIndex = posDataIndex + 1;                               
                           otherwise
                               error('There are more than 3 beacons for one of the Timestamps!');
                        end
                        beaconCounter = beaconCounter + 1;
                        if beaconCounter>3
                            break;
                        end
                    end
                end
            end
            output = posData;
        end
    end
    
	methods (Access = private, Static)
        function output = fReadJson(path, type)
                persistent runN

                f_content = dir(path);
                f_index   = 3;

                % Looking for JSON file in the folder
                for f=f_index:length(f_content)
                    extension = f_content(f).name;
                    if strcmp(extension(end-4:end), '.json')
                        if isempty(runN)
                            disp(['Processing ' f_content(f).name ' ...']);
                            runN = 0;
                        end
                        data = loadjson([path f_content(f).name]);
                        beacons_data = data{1}.beacons;
                        beaconsN = length(beacons_data);
                        break;
                    elseif f == length(f_content)
                        error(['There is no map JSON-file in a folder ' [pwd path]]);
                    end
                end

                % Choose the necessary information
                switch type
                    case 'beaconsN'
                        output = beaconsN;

                    case 'MAC'
                        beacOrderedMACs = cell(1, beaconsN);
                        for bN=1:beaconsN
                            beacOrderedMACs{bN} = beacons_data{bN}.macAddress;
                        end
                        output = beacOrderedMACs;
                    case 'MajorMinor'
                        MajorMinors = cell(3,beaconsN);
                        for bN=1:beaconsN
                            MajorMinors{1,bN} = strcat(int2str(beacons_data{bN}.major), int2str(beacons_data{bN}.minor));
                            MajorMinors{2,bN} = strcat(int2str(beacons_data{bN}.major));
                            MajorMinors{3,bN} = strcat(int2str(beacons_data{bN}.minor));
                        end
                        output = MajorMinors;
                        
                    case 'beaconsParams'
                        coords = cell(1, beaconsN);
                        for bN=1:beaconsN
                            coords{bN}.x = beacons_data{bN}.x;
                            coords{bN}.y = beacons_data{bN}.y;
                            coords{bN}.z = beacons_data{bN}.z;
                            coords{bN}.damp    = beacons_data{bN}.damp;
                            coords{bN}.txpower = beacons_data{bN}.txpower;
                        end
                        output = coords;

                    case 'map'        
                        mapParams.title     = data{1}.description;
                        mapParams.width     = data{1}.width;
                        mapParams.height    = data{1}.height;
                        mapParams.pixelSize = data{1}.pixelSize;
                        output = mapParams;
                end
        end
    end

    
end

